import { createFileRoute } from "@tanstack/react-router";
import logoAsset from "@/assets/raj-traders-logo-new.png.asset.json";
import heroPremium1 from "@/assets/hero-premium-1.jpg";
import heroPremium2 from "@/assets/hero-premium-2.jpg";
import heroPremium3 from "@/assets/hero-premium-3.jpg";
import heroPremium4 from "@/assets/hero-premium-4.jpg";
import bannerEnt from "@/assets/banner-entertainment.jpg";
import bannerWash from "@/assets/banner-washing.jpg";
import bannerAc from "@/assets/banner-ac.jpg";
import bannerFridge from "@/assets/banner-fridge.jpg";
import bannerNewArrivals from "@/assets/banner-newarrivals.jpg";
import promoMicrowave from "@/assets/promo-microwave.jpg";
import promoSmartphone from "@/assets/promo-smartphone.jpg";
import promoTv from "@/assets/promo-tv.jpg";
import promoWashing from "@/assets/promo-washing.jpg";
import product3 from "@/assets/product-3.png.asset.json";
import product4 from "@/assets/product-4.png.asset.json";
import product5 from "@/assets/product-5.png.asset.json";
import product6 from "@/assets/product-6.png.asset.json";
import product7 from "@/assets/product-7.png.asset.json";
import product8 from "@/assets/product-8.png.asset.json";
import product9 from "@/assets/product-9.png.asset.json";
import product10 from "@/assets/product-10.png.asset.json";
import product11 from "@/assets/product-11.png.asset.json";
import productN12 from "@/assets/product-new-12.png.asset.json";
import productN13 from "@/assets/product-new-13.png.asset.json";
import productN14 from "@/assets/product-new-14.png.asset.json";
import productN15 from "@/assets/product-new-15.png.asset.json";
import productN16 from "@/assets/product-new-16.png.asset.json";
import productN17 from "@/assets/product-new-17.png.asset.json";
import productN18 from "@/assets/product-new-18.png.asset.json";
import productN19 from "@/assets/product-new-19.png.asset.json";
import productN20 from "@/assets/product-new-20.png.asset.json";
import productN21 from "@/assets/product-new-21.png.asset.json";
import productN22 from "@/assets/product-new-22.png.asset.json";
import productN23 from "@/assets/product-new-23.png.asset.json";
import productN24 from "@/assets/product-new-24.png.asset.json";
import productN25 from "@/assets/product-new-25.png.asset.json";
import productN26 from "@/assets/product-new-26.png.asset.json";
import productN27 from "@/assets/product-new-27.png.asset.json";
import productN28 from "@/assets/product-new-28.png.asset.json";
import productN29 from "@/assets/product-new-29.png.asset.json";
import productN30 from "@/assets/product-new-30.png.asset.json";
import productN31 from "@/assets/product-new-31.png.asset.json";
import {
  MapPin,
  Package,
  Navigation,
  Phone,
  User,
  Heart,
  Search,
  Headphones,
  ShoppingCart,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Calendar,
  Gift,
  ShieldCheck,
  Percent,
  Wind,
  Laptop,
  Refrigerator,
  Tv,
  Smartphone,
  Microwave,
  Fan,
  Copy,
  Tag,
  HandCoins,
  Truck,
  PackageCheck,
  Handshake,
  FileText,
  Play,
  Mail,
  Facebook,
  Twitter,
  Instagram,
  MessageCircle,
  X,
  Plus,
  Minus,
  Trash2,
  Lightbulb,
  Flashlight,
  Flame,
  Utensils,
  Megaphone,
  Zap,
  Tv2,
  Sparkles,
  Plug,
  Droplet,
  AirVent,
  WashingMachine,
  Printer,
  Home,
  LayoutGrid,
} from "lucide-react";
import { useEffect, useRef, useState, createContext, useContext, useCallback, useMemo } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Raj Traders — Electronics, Appliances & More | Kalyanpura" },
      {
        name: "description",
        content:
          "Raj Traders — trusted store for Electronics, Electrical, Home Appliances, Mobiles, Kitchen Essentials and daily utility products. Kalyanpura.",
      },
      { property: "og:title", content: "Raj Traders — Electronics, Appliances & More | Kalyanpura" },
      {
        property: "og:description",
        content: "Raj Traders — trusted store for Electronics, Electrical, Home Appliances, Mobiles, Kitchen Essentials and daily utility products. Kalyanpura.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Product = {
  title: string;
  price: string;
  mrp: string;
  off: string;
  img: string;
};

// ------ Cart context ------
type CartItem = Product & { qty: number };
type CartCtx = {
  items: CartItem[];
  add: (p: Product) => void;
  remove: (title: string) => void;
  inc: (title: string) => void;
  dec: (title: string) => void;
  clear: () => void;
  count: number;
  open: boolean;
  setOpen: (b: boolean) => void;
};
const CartContext = createContext<CartCtx | null>(null);
const useCart = () => {
  const c = useContext(CartContext);
  if (!c) throw new Error("Cart not in tree");
  return c;
};

// ------ Wishlist context ------
type WishCtx = {
  items: Product[];
  toggle: (p: Product) => void;
  has: (title: string) => boolean;
  count: number;
  open: boolean;
  setOpen: (b: boolean) => void;
};
const WishlistContext = createContext<WishCtx | null>(null);
const useWishlist = () => {
  const c = useContext(WishlistContext);
  if (!c) throw new Error("Wishlist not in tree");
  return c;
};
function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Product[]>(() => {
    if (typeof window === "undefined") return [];
    try { return JSON.parse(localStorage.getItem("rt_wish") || "[]"); } catch { return []; }
  });
  const [open, setOpen] = useState(false);
  useEffect(() => { try { localStorage.setItem("rt_wish", JSON.stringify(items)); } catch {} }, [items]);
  const toggle = useCallback((p: Product) => {
    setItems((prev) => prev.some((x) => x.title === p.title)
      ? prev.filter((x) => x.title !== p.title)
      : [...prev, p]);
  }, []);
  const has = useCallback((t: string) => items.some((x) => x.title === t), [items]);
  return (
    <WishlistContext.Provider value={{ items, toggle, has, count: items.length, open, setOpen }}>
      {children}
    </WishlistContext.Provider>
  );
}

// ------ View / Search context ------
type View = "home" | "hotdeals" | "brands" | "search" | "wishlist";
type ViewCtx = {
  view: View;
  setView: (v: View) => void;
  query: string;
  setQuery: (q: string) => void;
  activeBrand: string | null;
  setActiveBrand: (b: string | null) => void;
};
const ViewContext = createContext<ViewCtx | null>(null);
const useView = () => {
  const c = useContext(ViewContext);
  if (!c) throw new Error("View not in tree");
  return c;
};
function ViewProvider({ children }: { children: React.ReactNode }) {
  const [view, setView] = useState<View>("home");
  const [query, setQuery] = useState("");
  const [activeBrand, setActiveBrand] = useState<string | null>(null);
  useEffect(() => { if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" }); }, [view, activeBrand]);
  return (
    <ViewContext.Provider value={{ view, setView, query, setQuery, activeBrand, setActiveBrand }}>
      {children}
    </ViewContext.Provider>
  );
}

const WHATSAPP_NUMBER = "919752144747";
const INSTAGRAM_URL = "https://www.instagram.com/raj_electronics_kalyanpura?igsh=NzdhbnlhMGp4d2pp&utm_source=qr";
const LOVABLE_ASSET_ORIGIN = "https://doc-duplicator-deluxe.lovable.app";
const parsePrice = (s: string) => Number(s.replace(/[^\d]/g, "")) || 0;
const cloneSafeAssetUrl = (url: string) =>
  url.startsWith("/__l5e/") ? `${LOVABLE_ASSET_ORIGIN}${url}` : url;

function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    if (typeof window === "undefined") return [];
    try {
      return JSON.parse(localStorage.getItem("rt_cart") || "[]");
    } catch {
      return [];
    }
  });
  const [open, setOpen] = useState(false);
  useEffect(() => {
    try {
      localStorage.setItem("rt_cart", JSON.stringify(items));
    } catch {}
  }, [items]);
  const add = useCallback((p: Product) => {
    setItems((prev) => {
      const i = prev.findIndex((x) => x.title === p.title);
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + 1 };
        return next;
      }
      return [...prev, { ...p, qty: 1 }];
    });
    setOpen(true);
  }, []);
  const remove = useCallback(
    (t: string) => setItems((p) => p.filter((x) => x.title !== t)),
    [],
  );
  const inc = useCallback(
    (t: string) =>
      setItems((p) => p.map((x) => (x.title === t ? { ...x, qty: x.qty + 1 } : x))),
    [],
  );
  const dec = useCallback(
    (t: string) =>
      setItems((p) =>
        p
          .map((x) => (x.title === t ? { ...x, qty: x.qty - 1 } : x))
          .filter((x) => x.qty > 0),
      ),
    [],
  );
  const clear = useCallback(() => setItems([]), []);
  const count = useMemo(() => items.reduce((a, b) => a + b.qty, 0), [items]);
  return (
    <CartContext.Provider
      value={{ items, add, remove, inc, dec, clear, count, open, setOpen }}
    >
      {children}
    </CartContext.Provider>
  );
}

function CartDrawer() {
  const { items, open, setOpen, inc, dec, remove, clear } = useCart();
  const total = items.reduce((a, b) => a + parsePrice(b.price) * b.qty, 0);
  const buyOnWhatsApp = () => {
    if (!items.length) return;
    const lines = items.map(
      (i, idx) =>
        `${idx + 1}. ${i.title} — ${i.price} x ${i.qty} = ₹${(parsePrice(i.price) * i.qty).toLocaleString("en-IN")}`,
    );
    const msg =
      `Hello Raj Traders, I would like to buy the following items:%0A%0A` +
      encodeURIComponent(lines.join("\n")) +
      `%0A%0A*Total: ₹${total.toLocaleString("en-IN")}*%0A%0APlease confirm availability.`;
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, "_blank");
  };
  return (
    <>
      {open && (
        <div
          className="fixed inset-0 bg-black/50 z-[60]"
          onClick={() => setOpen(false)}
        />
      )}
      <aside
        className={`fixed top-0 right-0 h-full w-full max-w-md bg-white text-[var(--text-on-white)] z-[70] shadow-2xl transform transition-transform ${
          open ? "translate-x-0" : "translate-x-full"
        } flex flex-col`}
      >
        <div className="flex items-center justify-between p-4 bg-[var(--kohinoor-blue)] text-white">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" /> My Cart ({items.length})
          </h3>
          <button aria-label="Close" onClick={() => setOpen(false)}>
            <X className="h-6 w-6" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {items.length === 0 && (
            <div className="text-center py-16 text-gray-500">
              <ShoppingCart className="h-14 w-14 mx-auto mb-3 opacity-40" />
              <p>Your cart is empty</p>
            </div>
          )}
          {items.map((it) => (
            <div key={it.title} className="flex gap-3 border-b pb-3">
              <img
                src={cloneSafeAssetUrl(it.img)}
                alt={it.title}
                className="h-20 w-20 object-contain bg-gray-50 rounded"
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold line-clamp-2">{it.title}</p>
                <p className="text-[var(--joy-price)] font-bold text-sm mt-1">
                  {it.price}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <button
                    aria-label="Decrease"
                    onClick={() => dec(it.title)}
                    className="h-6 w-6 border rounded flex items-center justify-center"
                  >
                    <Minus className="h-3 w-3" />
                  </button>
                  <span className="text-sm font-semibold w-6 text-center">
                    {it.qty}
                  </span>
                  <button
                    aria-label="Increase"
                    onClick={() => inc(it.title)}
                    className="h-6 w-6 border rounded flex items-center justify-center"
                  >
                    <Plus className="h-3 w-3" />
                  </button>
                  <button
                    aria-label="Remove"
                    onClick={() => remove(it.title)}
                    className="ml-auto text-red-500"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        {items.length > 0 && (
          <div className="border-t p-4 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Total</span>
              <span className="font-bold text-lg text-[var(--joy-price)]">
                ₹{total.toLocaleString("en-IN")}
              </span>
            </div>
            <button
              onClick={buyOnWhatsApp}
              className="w-full bg-[oklch(0.65_0.18_150)] text-white font-bold py-3 rounded-md flex items-center justify-center gap-2 hover:opacity-90"
            >
              <MessageCircle className="h-5 w-5" /> Buy Now on WhatsApp
            </button>
            <button
              onClick={clear}
              className="w-full text-xs text-gray-500 hover:text-red-500"
            >
              Clear cart
            </button>
          </div>
        )}
      </aside>
    </>
  );
}

// Real products from Raj Traders inventory
const ledBulbs: Product[] = [
  {
    title: "Eveready 9W LED Bulb B22 6500K Cool Day Light (4 Bulbs Value Pack)",
    price: "₹299",
    mrp: "₹499",
    off: "40% off",
    img: product3.url,
  },
  {
    title: "Surya Turbo Inverter Lamp 10W B22 — Upto 4 Hrs Backup, 25000 Hrs Life",
    price: "₹549",
    mrp: "₹899",
    off: "39% off",
    img: productN29.url,
  },
];

const torches: Product[] = [
  {
    title: "MZ M982 Pro LED Torch 200W High Power Rechargeable Telescopic Zoom",
    price: "₹1,299",
    mrp: "₹1,799",
    off: "28% off",
    img: product4.url,
  },
  {
    title: "MZ M035-C LED Torch 120 Lumen Rechargeable Long Range Focus Beam",
    price: "₹499",
    mrp: "₹799",
    off: "37% off",
    img: product5.url,
  },
  {
    title: "PowerCell LED Torch 9712B 0.75W Bright White Light",
    price: "₹149",
    mrp: "₹249",
    off: "40% off",
    img: product8.url,
  },
  {
    title: "Unibeam Dhurandar LED Torch — Rahe Kare Roshan",
    price: "₹179",
    mrp: "₹299",
    off: "40% off",
    img: product9.url,
  },
  {
    title: "Eveready DL40 0.5W Torch — Give Me Red (Free 3 AA Batteries)",
    price: "₹199",
    mrp: "₹299",
    off: "33% off",
    img: product10.url,
  },
  {
    title: "LAMAT LM-7704 Metal Torch 120W Zooming Head 1200mAh Type-C",
    price: "₹599",
    mrp: "₹999",
    off: "40% off",
    img: productN15.url,
  },
  {
    title: "Ujjwal Kisan 5 Star Rechargeable Torch 68mm Watt Reflector",
    price: "₹899",
    mrp: "₹1,299",
    off: "31% off",
    img: productN16.url,
  },
  {
    title: "Mono Onlite Dodo Upgraded Classic Rechargeable Torch (12W + 10W)",
    price: "₹249",
    mrp: "₹399",
    off: "38% off",
    img: productN18.url,
  },
];

const kitchenAppliances: Product[] = [
  {
    title: "Vioia Portable Geyser — Instant Water Heater for Hard & Soft Water",
    price: "₹1,999",
    mrp: "₹2,999",
    off: "33% off",
    img: product6.url,
  },
  {
    title: "Spare King G-Coil Hot Plate 1 Year Warranty — Fast Heating Stainless Steel",
    price: "₹1,850",
    mrp: "₹2,499",
    off: "26% off",
    img: product7.url,
  },
  {
    title: "BLU Berry Infrared Cooker — Crystal Glass, 4-Digit Display, Time Control",
    price: "₹2,499",
    mrp: "₹3,499",
    off: "29% off",
    img: productN12.url,
  },
  {
    title: "Fortuner Electric Immersion Water Heater — Shockproof (1 Year Warranty)",
    price: "₹499",
    mrp: "₹799",
    off: "38% off",
    img: productN17.url,
  },
  {
    title: "BLU BL-102 Fan Heater — Winter Solution (1 Year Warranty)",
    price: "₹1,299",
    mrp: "₹1,999",
    off: "35% off",
    img: productN21.url,
  },
  {
    title: "Standard Etna Pro Immersion Heater 1500W — 2 Year Warranty",
    price: "₹599",
    mrp: "₹899",
    off: "33% off",
    img: productN30.url,
  },
  {
    title: "Surya Sizzle Storage Water Heater / Geyser — Power Saver",
    price: "₹6,499",
    mrp: "₹8,999",
    off: "28% off",
    img: productN31.url,
  },
];

const streetLights: Product[] = [
  {
    title: "Reliable Evoke LED Street Light 36W IP65 Streetlight",
    price: "₹1,499",
    mrp: "₹2,199",
    off: "32% off",
    img: product11.url,
  },
  {
    title: "Reliable Evoke LED Street Light 50W IP65 Streetlight",
    price: "₹1,899",
    mrp: "₹2,699",
    off: "30% off",
    img: product11.url,
  },
  {
    title: "Reliable 100W LED Streetlight IP65 — 50,000+ Hours Life Span",
    price: "₹2,899",
    mrp: "₹3,999",
    off: "28% off",
    img: product11.url,
  },
  {
    title: "Sturmax 50W LED Flood Light IP66 — Outdoor Weatherproof",
    price: "₹1,199",
    mrp: "₹1,799",
    off: "33% off",
    img: productN19.url,
  },
];

// Fans
const fans: Product[] = [
  {
    title: "Fortuner Rockey 2.0 Pro Ceiling Fan 1200mm (48\") Smoke Brown — 405 RPM, 2 Year Warranty",
    price: "₹1,999",
    mrp: "₹2,899",
    off: "31% off",
    img: productN13.url,
  },
  {
    title: "BLU Mini Hanging Motor Fan — High Speed, CRC Stamping, Aerodynamic Blades",
    price: "₹1,299",
    mrp: "₹1,799",
    off: "28% off",
    img: productN22.url,
  },
];

// Speakers / Announce
const speakers: Product[] = [
  {
    title: "Rock Light S182-D Megaphone Bhopu 300W — 16 Voice, Bluetooth, USB, Double Battery",
    price: "₹2,199",
    mrp: "₹2,999",
    off: "27% off",
    img: productN14.url,
  },
];

// Cooler motor / spares
const coolerParts: Product[] = [
  {
    title: "Nerco 1\" Popular Cooler Motor with Ring — 105W, Powder Coated (1 Season Warranty)",
    price: "₹1,449",
    mrp: "₹1,999",
    off: "28% off",
    img: productN20.url,
  },
];

// DTH / Set Top Box
const dthDevices: Product[] = [
  {
    title: "BlueSky Digital Set Top Box — Direct to Home HD DVB Receiver with Remote",
    price: "₹1,199",
    mrp: "₹1,799",
    off: "33% off",
    img: productN23.url,
  },
];

// Decorative / Fairy Lights
const decorLights: Product[] = [
  {
    title: "LED Fairy String Lights — Warm White, Long Wire Rice Lights for Decoration",
    price: "₹199",
    mrp: "₹399",
    off: "50% off",
    img: productN24.url,
  },
];

// Electrical Accessories
const electricalAccessories: Product[] = [
  {
    title: "Eveready Everprotect Neo X2 Spike Guard — Fire Retardant, 2m Wire, 4 Sockets",
    price: "₹649",
    mrp: "₹899",
    off: "27% off",
    img: productN25.url,
  },
];

// Automotive Engine Oils
const engineOils: Product[] = [
  {
    title: "Havnol Force 15W40 API CI-4 Diesel Engine Oil — Heavy Duty (1 L)",
    price: "₹399",
    mrp: "₹549",
    off: "27% off",
    img: productN26.url,
  },
  {
    title: "Castrol Activ 20W40 4T Motorcycle Engine Oil — Actibond Technology (1 L)",
    price: "₹499",
    mrp: "₹650",
    off: "23% off",
    img: productN27.url,
  },
  {
    title: "Servo Pride TC 15W-40 Premium Diesel Engine Oil — API CH-4 (3 L)",
    price: "₹1,299",
    mrp: "₹1,650",
    off: "21% off",
    img: productN28.url,
  },
];

const categories = [
  { label: "LED Bulbs", icon: Lightbulb },
  { label: "Torches", icon: Flashlight },
  { label: "Kitchen & Heating", icon: Utensils },
  { label: "Street & Flood Lights", icon: Zap },
  { label: "Fans", icon: Fan },
  { label: "Speakers", icon: Megaphone },
  { label: "Cooler Parts", icon: Wind },
  { label: "DTH & Set Top Box", icon: Tv2 },
  { label: "Decorative Lights", icon: Sparkles },
  { label: "Electrical Accessories", icon: Plug },
  { label: "Automotive Oils", icon: Droplet },
  { label: "Air Conditioner", icon: AirVent },
  { label: "Washing Machine", icon: WashingMachine },
  { label: "Smart Phones", icon: Smartphone },
  { label: "Refrigerator", icon: Refrigerator },
  { label: "Laptops & Printer", icon: Printer },
];

const brands = [
  "FORTUNER",
  "BLU",
  "EVEREADY",
  "MZ",
  "RELIABLE",
  "STURMAX",
  "ROCK LIGHT",
  "NERCO",
  "LAMAT",
  "ONLITE",
  "UJJWAL KISAN",
  "POWERCELL",
  "SURYA",
  "STANDARD",
  "BLUESKY",
  "CASTROL",
  "SERVO",
  "HAVNOL",
];

function ProductCard({ p }: { p: Product }) {
  const { add } = useCart();
  const { toggle, has } = useWishlist();
  const wished = has(p.title);
  const buyNow = () => {
    const msg = encodeURIComponent(
      `Hello Raj Traders, I want to buy:\n${p.title}\nPrice: ${p.price}\nPlease confirm availability.`,
    );
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, "_blank");
  };
  return (
    <div className="snap-start min-w-0 shrink-0 basis-[70%] xs:basis-1/2 sm:basis-1/2 md:basis-1/3 lg:basis-1/4 xl:basis-1/5 px-2">
      <div className="rt-card bg-[var(--card-white)] text-[var(--text-on-white)] rounded-xl overflow-hidden flex flex-col h-full border border-black/5 shadow-[var(--premium-shadow)]">
        <div className="relative p-3 sm:p-4 bg-white overflow-hidden">
          <button
            aria-label={wished ? "Remove from wishlist" : "Add to wishlist"}
            aria-pressed={wished}
            onClick={() => toggle(p)}
            className={`absolute top-3 right-3 z-10 h-8 w-8 rounded-full bg-white/90 backdrop-blur border border-black/5 shadow-sm flex items-center justify-center rt-btn ${wished ? "text-[var(--kohinoor-red)]" : "text-[var(--text-on-white)]/60 hover:text-[var(--kohinoor-red)]"}`}
          >
            <Heart className="h-4 w-4" fill={wished ? "currentColor" : "none"} />
          </button>
          <div className="aspect-square w-full flex items-center justify-center">
            <img
              src={cloneSafeAssetUrl(p.img)}
              alt={p.title}
              loading="lazy"
              className="rt-img max-h-full max-w-full object-contain"
            />
          </div>
        </div>
        <div className="px-3 sm:px-4 pb-3 flex-1 flex flex-col">
          <p className="text-xs sm:text-sm font-semibold leading-snug min-h-[2.5rem] line-clamp-2 break-words">
            {p.title}
          </p>
          <p className="text-[var(--joy-price)] font-semibold mt-2 text-xs sm:text-sm">Joy Price</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-[var(--joy-price)] font-bold text-base sm:text-xl truncate">{p.price}</span>
            <span className="ml-auto shrink-0 bg-[var(--kohinoor-red)] text-white text-[10px] font-semibold px-2 py-1 rounded-full whitespace-nowrap">
              • {p.off}
            </span>
          </div>
          <p className="text-xs text-[var(--text-on-white)]/60 mt-0.5">
            MRP <span className="line-through">{p.mrp}</span>
          </p>
        </div>
        <div className="border-t border-black/10 flex text-[11px] sm:text-xs mt-auto">
          <button
            onClick={buyNow}
            className="rt-btn flex-1 min-w-0 flex items-center justify-center gap-1 py-2.5 hover:bg-[oklch(0.95_0.05_150)] font-semibold text-[oklch(0.5_0.18_150)] whitespace-nowrap"
          >
            <MessageCircle className="h-3.5 w-3.5" /> Buy Now
          </button>
          <div className="w-px bg-black/10" />
          <button
            onClick={() => add(p)}
            className="rt-btn flex-1 min-w-0 flex items-center justify-center gap-1 py-2.5 hover:bg-[oklch(0.95_0.04_245)] font-semibold text-[var(--kohinoor-blue)] whitespace-nowrap"
          >
            <ShoppingCart className="h-3.5 w-3.5" /> Add Cart
          </button>
        </div>
      </div>
    </div>
  );
}

function ProductSlider({
  title,
  products,
  viewAll = true,
}: {
  title?: string;
  products: Product[];
  viewAll?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useAutoScroll(ref, undefined, 3500);

  const scroll = (dir: -1 | 1) => {
    const el = ref.current;
    if (!el) return;
    el.scrollBy({ left: dir * el.clientWidth * 0.9, behavior: "smooth" });
  };

  return (
    <section className="max-w-[1280px] mx-auto px-3 sm:px-4 py-6 sm:py-8">
      {title && (
        <div className="flex items-center justify-between gap-3 mb-4">
          <h2 className="text-[var(--kohinoor-yellow)] font-bold text-base sm:text-lg min-w-0 truncate">{title}</h2>
          {viewAll && (
            <button className="text-[var(--kohinoor-yellow)] text-xs sm:text-sm font-semibold flex items-center gap-1 shrink-0 whitespace-nowrap">
              VIEW ALL <ChevronRight className="h-4 w-4" />
            </button>
          )}
        </div>
      )}
      <div className="relative">
        <button
          aria-label="Previous"
          onClick={() => scroll(-1)}
          className="hidden sm:flex absolute -left-1 top-1/2 -translate-y-1/2 z-10 h-9 w-9 rounded bg-white text-[var(--text-on-white)] shadow items-center justify-center hover:bg-white/90"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          aria-label="Next"
          onClick={() => scroll(1)}
          className="hidden sm:flex absolute -right-1 top-1/2 -translate-y-1/2 z-10 h-9 w-9 rounded bg-white text-[var(--text-on-white)] shadow items-center justify-center hover:bg-white/90"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
        <div
          ref={ref}
          className="flex overflow-x-auto scroll-smooth snap-x snap-mandatory -mx-2 px-2 sm:px-6 pb-2 items-stretch"
          style={{ scrollbarWidth: "none" }}
        >
          {products.map((p, i) => (
            <ProductCard key={i} p={p} />
          ))}
        </div>
      </div>
    </section>
  );
}

function CategorySlider() {
  const ref = useRef<HTMLDivElement>(null);
  useAutoScroll(ref, 400, 3500);
  return (
    <div className="max-w-[1280px] mx-auto px-2 sm:px-4 py-4 sm:py-6 relative">
      <div
        ref={ref}
        className="flex gap-4 sm:gap-8 overflow-x-auto px-2 sm:px-4 md:justify-between"
        style={{ scrollbarWidth: "none" }}
      >
        {categories.map(({ label, icon: Icon }) => (
          <button
            key={label}
            className="flex flex-col items-center gap-2 shrink-0 w-[84px] sm:w-[110px] group"
          >
            <div className="h-11 w-11 sm:h-14 sm:w-14 flex items-center justify-center text-[var(--kohinoor-yellow)]">
              <Icon strokeWidth={1.5} className="h-8 w-8 sm:h-10 sm:w-10" />
            </div>
            <span className="text-[var(--kohinoor-yellow)] text-[11px] sm:text-sm font-semibold text-center leading-tight break-words">
              {label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

function BrandSlider() {
  const ref = useRef<HTMLDivElement>(null);
  useAutoScroll(ref, 400, 3500);
  const scroll = (d: -1 | 1) => {
    ref.current?.scrollBy({ left: d * 400, behavior: "smooth" });
  };
  return (
    <div className="max-w-[1280px] mx-auto px-4 py-8">
      <h2 className="text-center text-white text-lg font-semibold mb-2">Top Brands</h2>
      <div className="mx-auto h-1 w-16 bg-[var(--kohinoor-blue)] mb-6" />
      <div className="relative">
        <button
          aria-label="Previous"
          onClick={() => scroll(-1)}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 h-9 w-9 rounded bg-white text-[var(--text-on-white)] shadow flex items-center justify-center"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          aria-label="Next"
          onClick={() => scroll(1)}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 h-9 w-9 rounded bg-white text-[var(--text-on-white)] shadow flex items-center justify-center"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
        <div
          ref={ref}
          className="flex gap-4 overflow-x-auto px-12 pb-2"
          style={{ scrollbarWidth: "none" }}
        >
          {brands.map((b) => (
            <div
              key={b}
              className="min-w-[150px] h-24 bg-white rounded-md flex items-center justify-center text-[var(--text-on-white)] font-bold tracking-wide"
            >
              {b}
            </div>
          ))}
        </div>
        <div className="flex justify-center mt-6">
          <button className="border-2 border-[var(--kohinoor-yellow)] text-[var(--kohinoor-yellow)] font-bold text-sm px-8 py-2 rounded-full">
            VIEW ALL
          </button>
        </div>
      </div>
    </div>
  );
}

function Index() {
  return (
    <CartProvider>
    <WishlistProvider>
    <ViewProvider>
    <IndexInner />
    </ViewProvider>
    </WishlistProvider>
    </CartProvider>
  );
}

const allProducts: { p: Product; category: string; brand: string }[] = [
  ...ledBulbs.map((p) => ({ p, category: "LED Bulbs", brand: firstWord(p.title) })),
  ...torches.map((p) => ({ p, category: "Torches", brand: firstWord(p.title) })),
  ...kitchenAppliances.map((p) => ({ p, category: "Kitchen & Heating", brand: firstWord(p.title) })),
  ...streetLights.map((p) => ({ p, category: "Street & Flood Lights", brand: firstWord(p.title) })),
  ...fans.map((p) => ({ p, category: "Fans", brand: firstWord(p.title) })),
  ...speakers.map((p) => ({ p, category: "Speakers", brand: firstWord(p.title) })),
  ...coolerParts.map((p) => ({ p, category: "Cooler Parts", brand: firstWord(p.title) })),
  ...dthDevices.map((p) => ({ p, category: "DTH & Set Top Box", brand: firstWord(p.title) })),
  ...decorLights.map((p) => ({ p, category: "Decorative Lights", brand: firstWord(p.title) })),
  ...electricalAccessories.map((p) => ({ p, category: "Electrical Accessories", brand: firstWord(p.title) })),
  ...engineOils.map((p) => ({ p, category: "Automotive Oils", brand: firstWord(p.title) })),
];
function firstWord(t: string) { return (t.split(/\s|—|-/)[0] || "").toUpperCase(); }

function hotDeals(): Product[] {
  return [...allProducts]
    .map((x) => ({
      ...x,
      offNum: parseInt(x.p.off.replace(/[^\d]/g, ""), 10) || 0,
    }))
    .sort((a, b) => b.offNum - a.offNum)
    .slice(0, 16)
    .map((x) => x.p);
}

function ProductGrid({ items }: { items: Product[] }) {
  if (!items.length) {
    return (
      <div className="max-w-[1280px] mx-auto px-4 py-16 text-center text-foreground/60">
        No products found.
      </div>
    );
  }
  return (
    <div className="max-w-[1280px] mx-auto px-3 sm:px-4 py-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
      {items.map((p, i) => (
        <div key={p.title + i} className="rt-fade-up" style={{ animationDelay: `${Math.min(i, 12) * 40}ms` }}>
          <GridProductCard p={p} />
        </div>
      ))}
    </div>
  );
}

function GridProductCard({ p }: { p: Product }) {
  // Reuse ProductCard's internals but without the slider basis widths
  return (
    <div className="[&>div]:!basis-full [&>div]:!px-0 [&>div]:!min-w-full">
      <ProductCard p={p} />
    </div>
  );
}

function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <section className="max-w-[1280px] mx-auto px-4 pt-8 pb-2 rt-fade-up">
      <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-foreground">{title}</h1>
      {subtitle && <p className="mt-2 text-sm sm:text-base text-foreground/60">{subtitle}</p>}
      <div className="mt-4 h-1 w-16 rounded-full bg-gradient-to-r from-[var(--kohinoor-blue)] to-[var(--kohinoor-yellow)]" />
    </section>
  );
}

function HotDealsView() {
  return (
    <>
      <PageHeader title="🔥 Hot Deals" subtitle="Biggest savings across the store — limited period only." />
      <ProductGrid items={hotDeals()} />
    </>
  );
}

function BrandsView() {
  const { activeBrand, setActiveBrand } = useView();
  const items = activeBrand
    ? allProducts.filter((x) => x.brand === activeBrand).map((x) => x.p)
    : [];
  return (
    <>
      <PageHeader title="Brand Store" subtitle="Shop by your favourite brand." />
      <div className="max-w-[1280px] mx-auto px-4 pb-2 flex flex-wrap gap-2">
        <button
          onClick={() => setActiveBrand(null)}
          className={`rt-btn px-4 py-2 rounded-full text-xs sm:text-sm font-semibold border ${!activeBrand ? "bg-[var(--kohinoor-blue)] text-white border-transparent" : "bg-white text-foreground border-black/10"}`}
        >All Brands</button>
        {brands.map((b) => (
          <button key={b}
            onClick={() => setActiveBrand(b)}
            className={`rt-btn px-4 py-2 rounded-full text-xs sm:text-sm font-semibold border ${activeBrand === b ? "bg-[var(--kohinoor-blue)] text-white border-transparent shadow-md" : "bg-white text-foreground border-black/10 hover:border-[var(--kohinoor-blue)]"}`}
          >{b}</button>
        ))}
      </div>
      {activeBrand ? (
        <ProductGrid items={items} />
      ) : (
        <div className="max-w-[1280px] mx-auto px-4 py-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {brands.map((b, i) => (
            <button key={b}
              onClick={() => setActiveBrand(b)}
              className="rt-card rt-fade-up bg-white rounded-xl border border-black/5 shadow-[var(--premium-shadow)] px-4 py-8 font-bold tracking-wide text-foreground"
              style={{ animationDelay: `${Math.min(i, 12) * 40}ms` }}
            >{b}</button>
          ))}
        </div>
      )}
    </>
  );
}

function SearchView() {
  const { query } = useView();
  const q = query.trim().toLowerCase();
  const items = q
    ? allProducts
        .filter((x) =>
          x.p.title.toLowerCase().includes(q) ||
          x.category.toLowerCase().includes(q) ||
          x.brand.toLowerCase().includes(q),
        )
        .map((x) => x.p)
    : [];
  return (
    <>
      <PageHeader title={q ? `Results for "${query}"` : "Search"} subtitle={q ? `${items.length} product${items.length === 1 ? "" : "s"} found` : "Type in the search bar to find products, brands or categories."} />
      {q && <ProductGrid items={items} />}
    </>
  );
}

function WishlistView() {
  const { items } = useWishlist();
  return (
    <>
      <PageHeader title="My Wishlist" subtitle={`${items.length} item${items.length === 1 ? "" : "s"} saved`} />
      <ProductGrid items={items} />
    </>
  );
}

function IndexInner() {
  const { view, setView, query, setQuery } = useView();
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Top utility bar */}
      <div className="hidden md:block bg-[var(--kohinoor-blue)] text-white text-xs">
        <div className="max-w-[1280px] mx-auto px-4 py-2 flex flex-wrap items-center justify-end gap-x-5 gap-y-2">
          {[
            { icon: MapPin, label: "Store Locator" },
            { icon: Package, label: "Track Your Order" },
            { icon: Phone, label: "Contact Us" },
            { icon: Instagram, label: "Follow us" },
          ].map(({ icon: I, label }, i, arr) => (
            <div key={label} className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <I className="h-3.5 w-3.5 text-[var(--kohinoor-yellow)]" />
                {label}
              </span>
              {i < arr.length - 1 && <span className="opacity-40">|</span>}
            </div>
          ))}
        </div>
      </div>

      {/* Header */}
      <header className="bg-black sticky top-0 z-40 md:static shadow-lg">
        <div className="max-w-[1280px] mx-auto px-3 sm:px-4 py-3 sm:py-4 flex flex-wrap items-center gap-3 sm:gap-6">
          <button onClick={() => setView("home")} className="flex items-center shrink-0 rt-btn">
            <img
              src={cloneSafeAssetUrl(logoAsset.url)}
              alt="Raj Traders"
              className="h-10 sm:h-14 md:h-16 w-auto object-contain"
            />
          </button>
          <div className="flex items-center gap-4 sm:gap-6 text-white text-sm ml-auto md:order-3">
            <a href="tel:+919752144747" className="hidden md:flex items-center gap-1.5 rt-btn">
              <Headphones className="h-4 w-4 text-[var(--kohinoor-yellow)]" />
              Customer Care
            </a>
            <WishlistButton />
            <CartButton />
          </div>
          <div className="order-last md:order-2 basis-full md:basis-0 md:flex-1 md:max-w-2xl min-w-0">
            <form
              onSubmit={(e) => { e.preventDefault(); setView("search"); }}
              className="bg-white rounded-full flex items-center px-4 py-2 shadow-inner ring-1 ring-black/5 focus-within:ring-[var(--kohinoor-blue)] transition"
            >
              <input
                type="text"
                value={query}
                onChange={(e) => { setQuery(e.target.value); if (view !== "search") setView("search"); }}
                placeholder="Search products, brands..."
                className="flex-1 min-w-0 bg-transparent outline-none text-sm text-[var(--text-on-white)] placeholder:text-[var(--text-on-white)]/50"
              />
              <button
                type="submit"
                aria-label="Search"
                className="bg-[var(--kohinoor-blue)] h-8 w-9 shrink-0 rounded-full flex items-center justify-center text-white rt-btn hover:bg-[var(--kohinoor-yellow)] hover:text-black"
              >
                <Search className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="max-w-[1280px] mx-auto px-3 sm:px-4 py-3 flex items-center gap-4 sm:gap-8 text-xs sm:text-sm overflow-x-auto whitespace-nowrap">
            <button onClick={() => setView("home")} className="text-[var(--kohinoor-yellow)] font-semibold flex items-center gap-1 shrink-0 rt-btn">
              All Categories <ChevronDown className="h-4 w-4" />
            </button>
            <button onClick={() => setView("hotdeals")} className={`shrink-0 font-semibold rt-btn ${view === "hotdeals" ? "text-[var(--kohinoor-yellow)]" : "text-white hover:text-[var(--kohinoor-yellow)]"}`}>Hot Deals</button>
            <button onClick={() => setView("brands")} className={`shrink-0 font-semibold rt-btn ${view === "brands" ? "text-[var(--kohinoor-yellow)]" : "text-white hover:text-[var(--kohinoor-yellow)]"}`}>Brands Store</button>
            <button onClick={() => setView("wishlist")} className={`shrink-0 font-semibold rt-btn ${view === "wishlist" ? "text-[var(--kohinoor-yellow)]" : "text-white hover:text-[var(--kohinoor-yellow)]"}`}>Wishlist</button>
          </div>
        </div>
      </header>

      {view === "hotdeals" && <HotDealsView />}
      {view === "brands" && <BrandsView />}
      {view === "search" && <SearchView />}
      {view === "wishlist" && <WishlistView />}

      {view === "home" && (<>
      {/* Hero */}
      <HeroSlider />
        <div className="bg-[oklch(0.25_0.1_290)] text-white">
          <div className="max-w-[1280px] mx-auto px-3 sm:px-4 py-3 flex flex-wrap items-center justify-center gap-3 sm:gap-6 text-xs sm:text-sm text-center">
            <span className="flex items-center gap-2">
              <Calendar className="h-4 w-4" /> Limited Period Offer
            </span>
            <span className="opacity-40 hidden sm:inline">|</span>
            <span>Pre-Reserve Now & Get More</span>
          </div>
        </div>

      <CategorySlider />

      {/* Category promo banners */}
      <section className="max-w-[1280px] mx-auto px-4 py-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        {[bannerEnt, bannerWash, bannerAc, bannerFridge].map((src, i) => (
          <a key={i} href="#" className="block rounded-lg overflow-hidden">
            <img src={src} alt="" loading="lazy" className="w-full h-auto block" />
          </a>
        ))}
      </section>

      <ProductSlider title="LED Bulbs" products={ledBulbs} />

      <ProductSlider title="Torches & Flashlights" products={torches} />

      <ProductSlider title="Kitchen & Heating Appliances" products={kitchenAppliances} />

      {/* 4 promo tiles */}
      <section className="max-w-[1280px] mx-auto px-4 py-6 grid grid-cols-2 md:grid-cols-4 gap-4">
        {[promoMicrowave, promoSmartphone, promoTv, promoWashing].map((src, i) => (
          <a key={i} href="#" className="block rounded-lg overflow-hidden">
            <img src={src} alt="" loading="lazy" className="w-full h-auto block" />
          </a>
        ))}
      </section>

      <ProductSlider title="LED Street & Flood Lights" products={streetLights} />

      <ProductSlider title="Ceiling Fans" products={fans} />

      <ProductSlider title="Speakers & Announce Systems" products={speakers} />

      <ProductSlider title="Cooler Motors & Spares" products={coolerParts} />

      <ProductSlider title="DTH & Set Top Box" products={dthDevices} />

      <ProductSlider title="Decorative & Fairy Lights" products={decorLights} />

      <ProductSlider title="Electrical Accessories" products={electricalAccessories} />

      <ProductSlider title="Automotive Engine Oils" products={engineOils} />

      {/* Video + brand tabs */}
      <section className="max-w-[1280px] mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-[1fr_180px] gap-3">
          <div className="relative aspect-[16/9] bg-black rounded-md overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=1200&auto=format"
              alt="Video"
              loading="lazy"
              className="w-full h-full object-cover opacity-80"
            />
            <button className="absolute inset-0 flex items-center justify-center">
              <div className="h-14 w-14 rounded-full bg-white/90 flex items-center justify-center">
                <Play className="h-6 w-6 text-[var(--kohinoor-blue)] fill-current" />
              </div>
            </button>
            <div className="absolute bottom-8 left-0 right-0 bg-[var(--kohinoor-blue)] text-white text-center py-2 font-semibold">
              Hello and Namaste Everyone!
            </div>
          </div>
          <div className="flex flex-col gap-2">
            {["KTV", "JBL", "Samsung", "LG"].map((b, i) => (
              <button
                key={b}
                className={`text-left px-4 py-4 font-semibold ${
                  i === 0
                    ? "bg-[var(--kohinoor-blue)] text-white"
                    : "bg-[var(--panel)] text-white/80"
                }`}
              >
                {b}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Why choose Kohinoor */}
      <section className="max-w-[1280px] mx-auto px-4 py-8 text-center">
        <h2 className="text-white font-bold text-2xl">Why choose Kohinoor</h2>
        <p className="text-[var(--kohinoor-yellow)] text-sm mt-2">
          Kohinoor's Promise of Joyful Experience & Assured Quality, Creating Milestones Since 1967
        </p>
        <p className="text-[var(--kohinoor-yellow)] text-sm">
          Your trusted destination for Consumer Electronics
        </p>
        <div className="mt-8 grid grid-cols-2 md:grid-cols-6 gap-4">
          {[
            { icon: Tag, label: "Best Offers & Prices" },
            { icon: HandCoins, label: "Multiple Payment Modes" },
            { icon: Truck, label: "Scheduled Delivery & Easy Installations" },
            { icon: PackageCheck, label: "No Cost EMI & Exchange Offers" },
            { icon: Handshake, label: "Exceptional Service" },
            { icon: FileText, label: "Multiple Extended Warranty Plans" },
          ].map(({ icon: I, label }, i, arr) => (
            <div
              key={label}
              className={`flex flex-col items-center gap-2 px-3 ${
                i < arr.length - 1 ? "md:border-r md:border-white/10" : ""
              }`}
            >
              <I className="h-10 w-10 text-[var(--kohinoor-yellow)]" strokeWidth={1.5} />
              <p className="text-[var(--kohinoor-yellow)] text-xs font-semibold">
                {label}
              </p>
            </div>
          ))}
        </div>
        <button className="mt-8 bg-[var(--kohinoor-yellow)] text-black text-sm font-semibold px-5 py-2 rounded-full inline-flex items-center gap-2">
          <Headphones className="h-4 w-4" /> Connect to expert
        </button>
      </section>

      {/* New Arrivals wide banner */}
      <section className="max-w-[1280px] mx-auto px-4 py-4">
        <a href="#" className="block rounded-md overflow-hidden">
          <img src={bannerNewArrivals} alt="New Arrivals" loading="lazy" className="w-full h-auto" />
        </a>
      </section>

      <BrandSlider />
      </>)}

      {/* Subscribe */}
      <section className="bg-[var(--kohinoor-blue)]">
        <div className="max-w-[1280px] mx-auto px-3 sm:px-4 py-6 flex flex-col md:flex-row items-center gap-4">
          <div className="flex items-center gap-3 text-white flex-1 min-w-0">
            <Mail className="h-8 w-8 shrink-0" />
            <div className="min-w-0">
              <p className="font-bold">Subscribe for new offers</p>
              <p className="text-xs opacity-90">
                We'll never share your email address with a any third party
              </p>
            </div>
          </div>
          <div className="flex w-full md:w-auto min-w-0">
            <input
              type="email"
              placeholder="Email address"
              className="flex-1 min-w-0 px-4 py-2.5 bg-white text-[var(--text-on-white)] rounded-l-md outline-none md:min-w-[280px]"
            />
            <button className="bg-[var(--kohinoor-yellow)] text-black font-bold px-4 sm:px-6 py-2.5 rounded-r-md shrink-0 whitespace-nowrap">
              Subscribe
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white">
        <div className="max-w-[1280px] mx-auto px-4 py-10 grid grid-cols-2 md:grid-cols-5 gap-8 text-sm">
          <div>
            <img
              src={cloneSafeAssetUrl(logoAsset.url)}
              alt="Raj Traders"
              className="h-20 w-auto object-contain mb-6"
            />
            <div className="flex items-center gap-3">
              <Headphones className="h-8 w-8 text-[var(--kohinoor-yellow)]" />
              <div className="text-xs">
                <p className="text-[var(--kohinoor-yellow)] font-semibold">
                  Got questions? Call us!
                </p>
                <p className="font-bold text-white text-base">+91 97521 44747</p>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="h-10 w-10 rounded-full bg-gradient-to-br from-[oklch(0.65_0.2_30)] via-[oklch(0.6_0.25_340)] to-[oklch(0.5_0.2_290)] flex items-center justify-center shadow-md rt-btn hover:scale-110"
              >
                <Instagram className="h-5 w-5 text-white" />
              </a>
            </div>
          </div>
          <div>
            <p className="text-[var(--kohinoor-yellow)] font-bold mb-4">Find it Fast</p>
            <ul className="space-y-2 text-[var(--kohinoor-yellow)]/90 text-xs">
              <li>Accessories</li>
              <li>Air Conditioner</li>
              <li>Laptops & Printer</li>
              <li>Home Appliances</li>
              <li>Home Entertainment</li>
            </ul>
          </div>
          <div>
            <p className="text-[var(--kohinoor-yellow)] font-bold mb-4 opacity-0">.</p>
            <ul className="space-y-2 text-[var(--kohinoor-yellow)]/90 text-xs">
              <li>Smart Phone</li>
              <li>Microwaves</li>
              <li>Air Coolers</li>
            </ul>
          </div>
          <div>
            <p className="text-[var(--kohinoor-yellow)] font-bold mb-4">My Account</p>
            <ul className="space-y-2 text-[var(--kohinoor-yellow)]/90 text-xs">
              <li>My Account</li>
              <li>Track Your Order</li>
              <li>Wish List</li>
            </ul>
            <p className="text-[var(--kohinoor-yellow)] font-bold mb-4 mt-6">About</p>
            <ul className="space-y-2 text-[var(--kohinoor-yellow)]/90 text-xs">
              <li>About Us</li>
              <li>Blogs</li>
              <li>Our Promise</li>
              <li>FAQ</li>
              <li>Testimonials</li>
              <li>Careers</li>
            </ul>
          </div>
          <div>
            <p className="text-[var(--kohinoor-yellow)] font-bold mb-4">Policies</p>
            <ul className="space-y-2 text-[var(--kohinoor-yellow)]/90 text-xs">
              <li>Privacy Policy</li>
              <li>Terms & Conditions</li>
              <li>Disclaimer</li>
              <li>Cancellation, Returns & Refunds</li>
            </ul>
          </div>
        </div>
        <div className="bg-[var(--kohinoor-blue)] text-white text-xs">
          <div className="max-w-[1280px] mx-auto px-3 sm:px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
            <p>
              © <span className="font-bold">Raj Traders</span> — All rights Reserved
            </p>
            <div className="flex flex-wrap justify-center gap-2 items-center text-[10px] font-bold">
              <span className="bg-white text-[var(--kohinoor-blue)] px-2 py-1 rounded">VISA</span>
              <span className="bg-white text-red-600 px-2 py-1 rounded">MC</span>
              <span className="bg-white text-blue-800 px-2 py-1 rounded">AMEX</span>
              <span className="bg-white text-black px-2 py-1 rounded">DC</span>
            </div>
          </div>
        </div>
      </footer>
      <FloatingWhatsApp />
      <CartDrawer />
      <MobileBottomNav />
      <div className="h-16 md:hidden" aria-hidden />
    </div>
  );
}

function CartButton() {
  const { count, setOpen } = useCart();
  return (
    <button onClick={() => setOpen(true)} className="flex items-center gap-1.5 relative rt-btn">
      <ShoppingCart className="h-4 w-4 text-[var(--kohinoor-yellow)]" />
      My Cart
      {count > 0 && (
        <span className="absolute -top-2 -right-3 bg-[var(--kohinoor-red)] text-white text-[10px] font-bold h-4 min-w-4 px-1 rounded-full flex items-center justify-center">
          {count}
        </span>
      )}
    </button>
  );
}

function WishlistButton() {
  const { count } = useWishlist();
  const { setView } = useView();
  return (
    <button onClick={() => setView("wishlist")} className="flex items-center gap-1.5 relative rt-btn" aria-label="Wishlist">
      <Heart className="h-4 w-4 text-[var(--kohinoor-yellow)]" />
      <span className="hidden sm:inline">Wishlist</span>
      {count > 0 && (
        <span className="absolute -top-2 -right-3 bg-[var(--kohinoor-red)] text-white text-[10px] font-bold h-4 min-w-4 px-1 rounded-full flex items-center justify-center">
          {count}
        </span>
      )}
    </button>
  );
}

function FloatingWhatsApp() {
  return (
    <a
      href="https://wa.me/919752144747"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-20 md:bottom-6 right-4 md:right-6 z-50 h-14 w-14 rounded-full bg-[oklch(0.65_0.18_150)] text-white shadow-lg flex items-center justify-center hover:scale-110 transition-transform animate-[pulse_2s_ease-in-out_infinite]"
    >
      <MessageCircle className="h-7 w-7" />
    </a>
  );
}

function MobileBottomNav() {
  const { count, setOpen } = useCart();
  const { count: wishCount } = useWishlist();
  const { setView } = useView();
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-black border-t border-white/10 pb-[env(safe-area-inset-bottom)]">
      <ul className="grid grid-cols-5 text-white text-[10px]">
        <li>
          <button onClick={() => setView("home")} className="w-full flex flex-col items-center justify-center gap-0.5 py-2 rt-btn">
            <Home className="h-5 w-5 text-[var(--kohinoor-yellow)]" /><span>Home</span>
          </button>
        </li>
        <li>
          <button onClick={() => setView("brands")} className="w-full flex flex-col items-center justify-center gap-0.5 py-2 rt-btn">
            <LayoutGrid className="h-5 w-5 text-[var(--kohinoor-yellow)]" /><span>Brands</span>
          </button>
        </li>
        <li>
          <button onClick={() => setView("search")} className="w-full flex flex-col items-center justify-center gap-0.5 py-2 rt-btn">
            <Search className="h-5 w-5 text-[var(--kohinoor-yellow)]" /><span>Search</span>
          </button>
        </li>
        <li>
          <button onClick={() => setView("wishlist")} className="w-full flex flex-col items-center justify-center gap-0.5 py-2 relative rt-btn">
            <Heart className="h-5 w-5 text-[var(--kohinoor-yellow)]" /><span>Wishlist</span>
            {wishCount > 0 && (
              <span className="absolute top-1 right-3 bg-[var(--kohinoor-red)] text-white text-[9px] font-bold h-4 min-w-4 px-1 rounded-full flex items-center justify-center">{wishCount}</span>
            )}
          </button>
        </li>
        <li>
          <button
            onClick={() => setOpen(true)}
            className="w-full flex flex-col items-center justify-center gap-0.5 py-2 relative rt-btn"
          >
            <ShoppingCart className="h-5 w-5 text-[var(--kohinoor-yellow)]" />
            <span>Cart</span>
            {count > 0 && (
              <span className="absolute top-1 right-3 bg-[var(--kohinoor-red)] text-white text-[9px] font-bold h-4 min-w-4 px-1 rounded-full flex items-center justify-center">
                {count}
              </span>
            )}
          </button>
        </li>
      </ul>
    </nav>
  );
}

function useAutoScroll(
  ref: React.RefObject<HTMLDivElement | null>,
  step?: number,
  interval = 3500,
) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let paused = false;
    const onEnter = () => (paused = true);
    const onLeave = () => (paused = false);
    el.addEventListener("mouseenter", onEnter);
    el.addEventListener("mouseleave", onLeave);
    const id = window.setInterval(() => {
      if (paused || !el) return;
      const dist = step ?? el.clientWidth * 0.9;
      const atEnd = el.scrollLeft + el.clientWidth >= el.scrollWidth - 4;
      if (atEnd) el.scrollTo({ left: 0, behavior: "smooth" });
      else el.scrollBy({ left: dist, behavior: "smooth" });
    }, interval);
    return () => {
      window.clearInterval(id);
      el.removeEventListener("mouseenter", onEnter);
      el.removeEventListener("mouseleave", onLeave);
    };
  }, [ref, step, interval]);
}

const heroSlides = [
  {
    eyebrow: "SAMSUNG",
    title: "New Shape. New Joy.",
    subtitle: "Something Bigger Coming Soon..",
    cta: "Pre-Reserve Starts Now",
    image: heroPremium1,
    tint: "linear-gradient(90deg, oklch(0.2 0.05 250 / 0.75), oklch(0.2 0.05 250 / 0.15))",
  },
  {
    eyebrow: "HOME APPLIANCES",
    title: "Upgrade Your Home",
    subtitle: "Fridges, ACs, Washing Machines & more",
    cta: "Shop Appliances",
    image: heroPremium2,
    tint: "linear-gradient(90deg, oklch(0.25 0.08 40 / 0.75), oklch(0.2 0.05 40 / 0.1))",
  },
  {
    eyebrow: "LED & LIGHTING",
    title: "Brighten Every Space",
    subtitle: "Premium bulbs, torches & street lights",
    cta: "Shop Lighting",
    image: heroPremium3,
    tint: "linear-gradient(90deg, oklch(0.22 0.08 260 / 0.75), oklch(0.2 0.05 260 / 0.1))",
  },
  {
    eyebrow: "FANS & COOLING",
    title: "Stay Cool. Stay Comfortable.",
    subtitle: "Ceiling fans, coolers & spare parts",
    cta: "Shop Cooling",
    image: heroPremium4,
    tint: "linear-gradient(90deg, oklch(0.22 0.08 200 / 0.75), oklch(0.2 0.05 200 / 0.1))",
  },
];

function HeroSlider() {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => {
      setIdx((i) => (i + 1) % heroSlides.length);
    }, 4500);
    return () => window.clearInterval(id);
  }, []);
  const go = (d: -1 | 1) =>
    setIdx((i) => (i + d + heroSlides.length) % heroSlides.length);
  return (
    <section className="relative">
      <div className="max-w-[1280px] mx-auto px-4 relative">
        <div className="relative rounded-2xl overflow-hidden h-[280px] md:h-[460px] shadow-[var(--premium-shadow-lg)]">
          {heroSlides.map((s, i) => (
            <div
              key={i}
              className="absolute inset-0 transition-opacity duration-700"
              style={{
                opacity: i === idx ? 1 : 0,
                pointerEvents: i === idx ? "auto" : "none",
              }}
            >
              <img src={s.image} alt={s.title} className={`absolute inset-0 h-full w-full object-cover ${i === idx ? "rt-fade-in" : ""}`} style={{ transform: i === idx ? "scale(1.04)" : "scale(1)", transition: "transform 6s ease-out" }} />
              <div className="absolute inset-0" style={{ background: s.tint }} />
              <div className="relative h-full flex flex-col justify-center px-6 sm:px-10 md:px-16 max-w-2xl">
                <p className="text-[var(--kohinoor-yellow)] font-semibold text-xs sm:text-sm tracking-[0.2em] rt-fade-up">
                  {s.eyebrow}
                </p>
                <h1 className="text-white font-black text-3xl sm:text-5xl md:text-6xl mt-3 sm:mt-4 drop-shadow-xl leading-tight rt-fade-up" style={{ animationDelay: "80ms" }}>
                  {s.title}
                </h1>
                <p className="text-white/90 text-sm sm:text-lg md:text-xl mt-2 sm:mt-3 rt-fade-up" style={{ animationDelay: "160ms" }}>
                  {s.subtitle}
                </p>
                <div className="mt-5 sm:mt-6 rt-fade-up" style={{ animationDelay: "240ms" }}>
                  <button className="bg-[var(--kohinoor-yellow)] text-black font-bold px-5 sm:px-7 py-2.5 sm:py-3 rounded-full text-xs sm:text-sm shadow-lg rt-btn hover:bg-white">
                    {s.cta}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <button
          aria-label="Previous"
          onClick={() => go(-1)}
          className="absolute left-6 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/90 text-[var(--text-on-white)] flex items-center justify-center shadow-md rt-btn hover:bg-white"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          aria-label="Next"
          onClick={() => go(1)}
          className="absolute right-6 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/90 text-[var(--text-on-white)] flex items-center justify-center shadow-md rt-btn hover:bg-white"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
          {heroSlides.map((_, i) => (
            <button
              key={i}
              onClick={() => setIdx(i)}
              aria-label={`Slide ${i + 1}`}
              className={`h-2 rounded-full transition-all ${
                i === idx ? "w-8 bg-white" : "w-2 bg-white/50"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
